<?php
/**
 * @package WordPress
 * @subpackage Adventure_Journal
 */
?>
			<!-- begin footer -->
			<div class="clear"></div>
            <div id="footer">
				<div class="nav-horz nav-footer"><?php  wp_nav_menu( array( 'theme_location' => 'footer-menu' ) ); ?></div>
				<?php wp_footer(); ?>
				<div class="clear"></div> 
            </div>
          </div>
        </div>
		<div id="colophon">
			<a id="ctxophon" href="http://www.contextureintl.com/?sref=aj" title="A WordPress Theme by Contexture International"></a>
			<a id="wpophon" href="http://www.wordpress.org" title="Powered by WordPress"></a>
			<div class="clear"></div>
		</div>
    </div>
</body>
</html>